CREATE SCHEMA IF NOT EXISTS ristorantiDB;
use ristorantiDB;

CREATE TABLE IF NOT EXISTS ristorante(
Città VARCHAR(30) NOT NULL,
Indirizzo VARCHAR(200) NOT NULL,
PRIMARY KEY (Città,Indirizzo)
);


CREATE TABLE IF NOT EXISTS dipendenti(
CF CHAR(16) NOT NULL,
ScadenzaContratto CHAR(10),
AnniEsperienza INT,
Nome VARCHAR(20),
Cognome VARCHAR(30),
Età INT,
Città VARCHAR(30),
Indirizzo VARCHAR(200),
CFRES CHAR(16),
Responsabile Tinyint,
Username CHAR(16) NOT NULL,
Psw CHAR(30) NOT NULL,

PRIMARY KEY (CF),
FOREIGN KEY(Città, Indirizzo) REFERENCES ristorante(Città,Indirizzo) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS cuoco(
CF CHAR(16) NOT NULL,
Specializzazione VARCHAR(20),
PRIMARY KEY(CF),
	FOREIGN KEY (CF) REFERENCES dipendenti (CF) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS cameriere(
CF CHAR(16) NOT NULL,

PRIMARY KEY(CF),
	FOREIGN KEY(CF) references dipendenti(CF) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS menu(
ID INT NOT NULL,
Tipo VARCHAR(20),
PRIMARY KEY (ID)
);

CREATE TABLE IF NOT EXISTS ricetta(
Nome VARCHAR(50) NOT NULL,
Categoria VARCHAR(20) NOT NULL,
Prezzo DOUBLE,
PRIMARY KEY(Nome)
);

CREATE TABLE IF NOT EXISTS ingredienti(
Nome VARCHAR(20) NOT NULL,
Quantità INT,
PRIMARY KEY (Nome)
);

CREATE TABLE IF NOT EXISTS cliente(
CF CHAR(16) NOT NULL,
Cognome VARCHAR(20),
Nome VARCHAR(20),
Mail VARCHAR(50),
UsernameC CHAR(30) NOT NULL,
Psw CHAR(60) NOT NULL,
Admin Tinyint NOT NULL,

PRIMARY KEY(CF)
);

CREATE TABLE IF NOT EXISTS ordine(
Codice INT NOT NULL,
Data CHAR(10),
Ora VARCHAR(5),
Città VARCHAR(30) NOT NULL,
Indirizzo VARCHAR(200) NOT NULL,
CFCliente CHAR(16) NOT NULL,
PRIMARY KEY(Codice),

FOREIGN KEY (Città,Indirizzo) REFERENCES ristorante(Città,Indirizzo) ON DELETE CASCADE,
FOREIGN KEY (CFCliente) REFERENCES cliente(CF) ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS telefonoRis(
Numero CHAR(10) NOT NULL,
Città VARCHAR(30) NOT NULL,
Indirizzo VARCHAR(200) NOT NULL,
PRIMARY KEY(Numero),

FOREIGN KEY (Città,Indirizzo) REFERENCES ristorante(Città,Indirizzo) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS telefonoDip(
Numero CHAR(10) NOT NULL,
CFDIP CHAR(16) NOT NULL,

PRIMARY KEY(Numero),

foreign key(CFDIP) REFERENCES dipendenti(CF) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS ha(
Città VARCHAR(30) NOT NULL,
Indirizzo VARCHAR(200) NOT NULL,
ID INT NOT NULL,
PRIMARY KEY(Città,Indirizzo,ID),
 FOREIGN KEY(Città,Indirizzo) REFERENCES ristorante(Città,Indirizzo) ON DELETE CASCADE,
  FOREIGN KEY(ID) REFERENCES menu(ID) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS formato(
ID INT NOT NULL,
Nome VARCHAR(50) NOT NULL,
PRIMARY KEY(ID,Nome),
	FOREIGN KEY(ID) REFERENCES menu(ID) ON DELETE CASCADE,
		FOREIGN KEY(Nome) REFERENCES ricetta(Nome) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS usa(
NomeRicetta VARCHAR(50) NOT NULL,
NomeIngrediente VARCHAR(20) NOT NULL,
PRIMARY KEY(NomeRicetta, NomeIngrediente),
 FOREIGN KEY(NomeRicetta) REFERENCES ricetta(Nome) ON DELETE CASCADE,
  FOREIGN KEY(NomeIngrediente) REFERENCES ingredienti(Nome) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS compone(
NomeRicetta VARCHAR(50) NOT NULL,
CODICE INT NOT NULL,


FOREIGN KEY(NomeRicetta) REFERENCES ricetta(Nome) ON DELETE CASCADE,
FOREIGN KEY(CODICE) REFERENCES ordine(Codice) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS carrello(
ID INT NOT NULL,
CF CHAR(16) NOT NULL,

PRIMARY KEY(ID),
FOREIGN KEY(CF) REFERENCES cliente(CF) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS contiene(
ID INT,
NomeRicetta VARCHAR(50),
Quantità INT,

FOREIGN KEY(ID) REFERENCES carrello(ID) ON DELETE CASCADE,
FOREIGN KEY(NomeRicetta) REFERENCES ricetta(Nome) ON DELETE CASCADE
);



LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileRistoranti.txt' INTO TABLE ristorante FIELDS terminated by ',' LINES terminated by '/' (Città,Indirizzo);
LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileDipendenti.txt' INTO TABLE dipendenti FIELDS terminated by ',' LINES terminated by '/' (CF,ScadenzaContratto,AnniEsperienza,Nome,Cognome,Età,Città,Indirizzo,Responsabile,CFRES,username,Psw);
LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileMenu.txt' INTO TABLE menu FIELDS terminated by ',' LINES terminated by '/' (ID,Tipo);
LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileRicetta.txt' INTO TABLE ricetta FIELDS terminated by ',' LINES terminated by '/' (Nome,Categoria,Prezzo);
LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileIngredienti.txt' INTO TABLE ingredienti FIELDS terminated by ',' LINES terminated by '\n' (Nome,Quantità);
LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileCameriere.txt' INTO TABLE cameriere FIELDS terminated by ',' LINES terminated by '\n' (CF);
LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileCliente.txt' INTO TABLE cliente FIELDS terminated by ',' LINES terminated by '\n' (CF,Cognome,Nome,Mail,UsernameC,Psw,Admin);
LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileOrdini.txt' INTO TABLE ordine FIELDS terminated by ',' LINES terminated by '\n' (Codice,Data,Ora,Città,Indirizzo,CFCliente);
LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileCuoco.txt' INTO TABLE cuoco FIELDS terminated by ',' LINES terminated by '\n' (CF,Specializzazione);
LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileHa.txt' INTO TABLE ha FIELDS terminated by ',' LINES terminated by '\n' (Città,Indirizzo,ID);
LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileTelefonoRis.txt' INTO TABLE telefonoRis FIELDS terminated by ',' LINES terminated by '\n' (Città,Indirizzo,Numero);
LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileTelefonoRes.txt' INTO TABLE telefonoDip FIELDS terminated by ',' LINES terminated by '\n' (Numero,CFDIP);
LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileFormato.txt' INTO TABLE formato FIELDS terminated by ',' LINES terminated by '/' (ID,Nome);
LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileUsa.txt' INTO TABLE usa FIELDS terminated by ',' LINES terminated by '/' (NomeRicetta,NomeIngrediente);
LOAD DATA LOCAL INFILE 'C:/Users/fraea/workspace/TheShireWebProject/db/filePopolazione/fileCompone.txt' INTO TABLE compone FIELDS terminated by ',' LINES terminated by '\n' (NomeRicetta,Codice);
