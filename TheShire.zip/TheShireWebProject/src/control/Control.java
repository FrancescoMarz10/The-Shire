package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.MenuBean;
import bean.RicetteBean;
import model.CartModel;
import model.RicetteModel;
import model.RistoranteModel;

/**
 * Servlet implementation class Control
 */
@WebServlet("/Control")
public class Control extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	static RicetteModel model = new RicetteModel();
	
	static RistoranteModel model1= new RistoranteModel();
    public Control() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	/*	String Citt�= request.getParameter("Citt�");
		String Indirizzo= request.getParameter("Indirizzo");
		Collection<MenuBean> menu= new ArrayList<MenuBean>();
		
		try {
			
			request.setAttribute("menu", model1.TrovaMenu(Citt�,Indirizzo));
		
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		*/
	
		String action= request.getParameter("action");
		try{
		if(action!=null){
		
			if(action.equalsIgnoreCase("read")){
				String nome=request.getParameter("nome");
				request.removeAttribute("product");
				request.setAttribute("product", model.doRetrieveByKey(nome));
			}
		}
	}
	catch(SQLException er){
		System.out.println("Error:"+ er.getMessage());
		request.setAttribute("error", er.getMessage());
	}
		
	String sort= request.getParameter("sort");
	
	try{
		request.removeAttribute("products");
		request.setAttribute("products", model.doRetrieveAll(sort));
	}
	catch(SQLException e){
		System.out.println("Error:"+ e.getMessage());
		request.setAttribute("error", e.getMessage());
	}
	
	RequestDispatcher dispatcher= getServletContext().getRequestDispatcher("/Menu.jsp");
	dispatcher.forward(request, response);
}

	


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}