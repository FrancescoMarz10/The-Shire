package control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.IngredientiBean;
import bean.RicetteBean;
import model.RicetteModel;

/**
 * Servlet implementation class AdminControl
 */
@WebServlet("/admin/AdminControl")
public class AdminControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static RicetteModel model = new RicetteModel();   
    
    public AdminControl() {
        super();
      
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action= request.getParameter("action");
		try{
		if(action!=null){
			

			if(action.equalsIgnoreCase("delete")){
				String nome=request.getParameter("nome");
				model.CancellaRicetta(nome);
			}
			else if(action.equalsIgnoreCase("updateQuantity")){
				String nome=request.getParameter("Ingr");
				int quantity=Integer.parseInt(request.getParameter("q"));
				
				model.aggiornaQ(quantity, nome);
			}
			
			else if(action.equalsIgnoreCase("updatePrice")){
				String nome=request.getParameter("Ricet");
				double price=Double.parseDouble(request.getParameter("prezzoo"));
				
				model.aggiornaPrice(price, nome);
			}
			else if(action.equalsIgnoreCase("insert")){
				String name= request.getParameter("nome");
				System.out.println(name);
				String description= request.getParameter("categoria");
				System.out.println(description);
				double price=Double.parseDouble(request.getParameter("prezzo"));
				System.out.println(price);
				String[] ingredienti=request.getParameterValues("nomeI");
				
				
				String nameI="";
				if(request.getParameter("IngNew")!=""){
					nameI=request.getParameter("IngNew");
					System.out.println(nameI);
				}else{
					nameI=null;
				}
				
				int quantity=Integer.parseInt(request.getParameter("quantit�"));
				String menu=request.getParameter("TipoMenu");
			
				
				RicetteBean bean= new RicetteBean();
				IngredientiBean beanI=new IngredientiBean();
				bean.setNome(name);
				bean.setCategoria(description);
				bean.setPrezzo(price);
				beanI.setNome(nameI);
				beanI.setQuantit�(quantity);
			
				if(ingredienti!=null){
					for (String string : ingredienti) {
						
						model.inserisciRicetta(bean,string,beanI,menu);  
					}
				}
				else{
					String string=null;
					model.inserisciRicetta(bean,string,beanI,menu);
				}
			}
		
		}
	}
	catch(SQLException er){
		System.out.println("Error:"+ er.getMessage());
		request.setAttribute("error", er.getMessage());
	}

	String sort= request.getParameter("sort");
	
	try{
		request.removeAttribute("products");
		request.setAttribute("products", model.doRetrieveAll(sort));
	}
	catch(SQLException e){
		System.out.println("Error:"+ e.getMessage());
		request.setAttribute("error", e.getMessage());
	}
	
	RequestDispatcher dispatcher= getServletContext().getRequestDispatcher("/admin/MenuLoggatoAdmin.jsp");
	dispatcher.forward(request, response);
	}
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);

	
}
	}


