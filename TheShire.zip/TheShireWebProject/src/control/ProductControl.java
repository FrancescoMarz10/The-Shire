package control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.ClienteBean;
import bean.RicetteBean;
import model.CartModel;
import model.ClientModel;
import model.RicetteModel;

@WebServlet("/user/ProductControl")
public class ProductControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static RicetteModel model = new RicetteModel();
	ClientModel model1=new ClientModel();
 
    public ProductControl() {
        super();
      
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ClienteBean bean=(ClienteBean)request.getSession().getAttribute("bean");
		CartModel cart= (CartModel) request.getSession().getAttribute("cart");
		if(cart== null){
			cart= new CartModel();
			try {
				cart.setProducts(model1.caricaCarrello(bean));
				System.out.println("carrello caricato");
				request.getSession().setAttribute("cart", cart);
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			request.getSession().setAttribute("cart", cart);
		}
		
		String action= request.getParameter("action");
		try{
		if(action!=null){
			
			if(action.equalsIgnoreCase("addC")){
				
				
				bean=(ClienteBean)request.getSession().getAttribute("bean");
				String nome=request.getParameter("nome");
				cart.addProduct(model.doRetrieveByKey(nome),bean.getCF());
			}
			
			else if(action.equalsIgnoreCase("deleteC")){
				String nome=request.getParameter("nome");
				cart.deleteProduct(model.doRetrieveByKey(nome));
				
			}
		}
		}
	catch(SQLException er){
		System.out.println("Error:"+ er.getMessage());
		request.setAttribute("error", er.getMessage());
	}
	
	
	request.getSession().setAttribute("cart", cart);
	request.setAttribute("cart", cart);
	
	String sort= request.getParameter("sort");
	
	try{
		request.removeAttribute("products");
		request.setAttribute("products", model.doRetrieveAll(sort));
	}
	catch(SQLException e){
		System.out.println("Error:"+ e.getMessage());
		request.setAttribute("error", e.getMessage());
	}
	
	RequestDispatcher dispatcher= getServletContext().getRequestDispatcher("/user/MenuLoggato.jsp");
	dispatcher.forward(request, response);
}

	


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
