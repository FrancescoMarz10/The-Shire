package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.MenuBean;
import model.RicetteModel;
import model.RistoranteModel;

@WebServlet("/MenuServlet")
public class MenuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    RicetteModel model= new RicetteModel();
    public MenuServlet() {
        super();
      
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Citt�= request.getParameter("Citt�");
		System.out.println(Citt�);
		String Indirizzo= request.getParameter("Indirizzo");
		String tipo=request.getParameter("tipimenu");
		String tipopasto= request.getParameter("tipopasto");
		try {
			request.setAttribute("products", model.TrovaRicette(Citt�,Indirizzo,tipo,tipopasto));
			RequestDispatcher dispatcher= getServletContext().getRequestDispatcher("/Menu.jsp");
			dispatcher.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
