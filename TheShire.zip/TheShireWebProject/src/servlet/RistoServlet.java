package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.ClienteBean;
import bean.DipendentiBean;
import bean.RistoranteBean;
import model.RistoranteModel;

/**
 * Servlet implementation class RistoServlet
 */
@WebServlet("/admin/RistoServlet")
public class RistoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
      RistoranteModel model= new RistoranteModel();

    public RistoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		int result=1;
		if(action!=null){
			if(action.equals("insert")){
				
				String citt�=request.getParameter("city");
				String indirizzo=request.getParameter("indirizzo");
				String nome=request.getParameter("nome");
				String cognome=request.getParameter("cognome");
				String CFAdmin=request.getParameter("CFAdmin");
				String scadenza=request.getParameter("scadenza");
				int et�=Integer.parseInt(request.getParameter("et�"));
				int anni=Integer.parseInt(request.getParameter("anniEsperienza"));
				String telefono=request.getParameter("telefono");
				String telefonoR=request.getParameter("telefonoR");
				String username="admin";
				String password="0000";
				String[] menu=request.getParameterValues("menu");
				
				for (String string : menu) {
					System.out.println(string);
				}
				
				RistoranteBean bean= new RistoranteBean();
				DipendentiBean dip= new DipendentiBean();
				
				bean.setCitt�(citt�);
				bean.setIndirizzo(indirizzo);
				
				dip.setCF(CFAdmin);
				dip.setCFRES(CFAdmin);
				dip.setCitt�(citt�);
				dip.setIndirizzo(indirizzo);
				dip.setCognome(cognome);
				dip.setAnniEsperienza(anni);
				dip.setNome(nome);
				dip.setEt�(et�);
				dip.setScadenzaContratto(scadenza);
				
				try {
					int i=0;
					if(menu!=null){	
						for (String string : menu) {
							System.out.println(string);
						
								result=model.InserisciRisto(bean, dip, username, password, string, telefono, telefonoR,i);
									i++;

						}
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
				}
			}
			
			else if(action.equals("delete")){
				String citt�=request.getParameter("citta");
				String indirizzo=request.getParameter("via");
				
				try {
					model.eliminaRisto(citt�, indirizzo);
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		
		
		
		if(result==0){
			
			RequestDispatcher dispatcher= getServletContext().getRequestDispatcher("/admin/FailinsertRisto.jsp");
			dispatcher.forward(request, response);
		}
		
	
		else{
			
			RequestDispatcher dispatcher= getServletContext().getRequestDispatcher("/admin/RistoranteLoggatoAdmin.jsp");
			dispatcher.forward(request, response);
		
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
