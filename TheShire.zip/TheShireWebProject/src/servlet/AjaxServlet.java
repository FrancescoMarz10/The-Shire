package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.RistoranteModel;

/*
 * Servlet implementation class IbanServlet
 */
@WebServlet("/AjaxServlet")
public class AjaxServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public AjaxServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/xml");
		
		StringBuffer packed = new StringBuffer();
		packed.append("<info>");
				
		String param = (String)request.getParameter("Citta");

		RistoranteModel model= new RistoranteModel();
		Collection<String> vie= new ArrayList<String>();
		
		try {
			vie=(Collection<String>) model.TrovaVia(param);
		}catch(SQLException e) {
			
		}
		
		
		if(param != null) {
			int size=0;
			for(String risto: vie) {
					packed.append("<risto>");
					packed.append(risto);
					packed.append("</risto>");
					size++;
			}
			packed.append("<size>");
			packed.append(size);
			packed.append("</size>");

		}
	
		packed.append("</info>");
		response.getWriter().write(packed.toString());
	}

}
