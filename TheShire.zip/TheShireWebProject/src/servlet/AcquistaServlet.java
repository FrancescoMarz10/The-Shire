package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.ClienteBean;
import bean.RicetteBean;
import bean.RistoranteBean;
import model.CartModel;
import model.OrdineModel;

@WebServlet("/user/AcquistaServlet")
public class AcquistaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    OrdineModel model= new OrdineModel();
    CartModel model1 = new CartModel();
    
    public AcquistaServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ClienteBean bean=(ClienteBean)request.getSession().getAttribute("bean");
		RistoranteBean risto= new RistoranteBean();
		risto.setCitt�(	(String) request.getSession().getAttribute("citta"));
		risto.setIndirizzo((String) request.getSession().getAttribute("indi"));
		model1=(CartModel) request.getSession().getAttribute("cart");
		List<RicetteBean> products=model1.getProducts();	
	
		try {
			int i=0;
			for (RicetteBean ricetteBean : products) {

				model.Acquista(bean, risto, ricetteBean,i);
				i++;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		CartModel cart=new CartModel();
		request.getSession().setAttribute("cart", cart);
		request.setAttribute("cart", cart);
	
		
		RequestDispatcher dispatcher= getServletContext().getRequestDispatcher("/user/AcquistoCompleto.jsp");
		dispatcher.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
