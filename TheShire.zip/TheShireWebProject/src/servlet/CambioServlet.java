package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.ClienteBean;
import model.ClientModel;

/**
 * Servlet implementation class CambioServlet
 */
@WebServlet("/CambioServlet")
public class CambioServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ClientModel model= new ClientModel();
      
    public CambioServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("newUser");
		String password= request.getParameter("newPsw");
		ClienteBean bean= (ClienteBean) request.getSession().getAttribute("bean");
		String error="";
	
		
		if(username == null || username.trim().equals("")) {
			error+= "Inserisci Username <br>"; 
		} else {
			request.setAttribute("username", username);
		}

		if(password == null || password.trim().equals("")) {
			error+= "Inserisci Password <br>";
		}
		
		try{
			model.changePsw(username,password,bean);
			bean=model.checkUser(username, password);
			boolean logged=true;
			if(!bean.getCF().equals("")){
				//redirectPage="/logged.jsp";
				//response.sendRedirect(request.getContextPath() + redirectPage);
				request.getSession().setAttribute("logged", logged);
				request.getSession().setAttribute("bean", bean);
				HttpSession session= request.getSession();
				if(logged){
					synchronized (session) {
						request.getSession().setAttribute("username", bean.getUsername());
						RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/UserServlet"); 
						dispatcher.forward(request, response);
					}
				}				
			}
			else{
				error="Invalid username and password";
				request.setAttribute("error", error);
				
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/fail.jsp"); 
				dispatcher.forward(request, response);
				//redirectPage="/contatti.jsp";
				//response.sendRedirect(request.getContextPath() + redirectPage);
			}
		
		}catch (Exception e) {
		
	}
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
