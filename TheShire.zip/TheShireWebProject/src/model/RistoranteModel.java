package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;

import com.sun.org.apache.regexp.internal.recompile;

import bean.ClienteBean;
import bean.DipendentiBean;
import bean.MenuBean;
import bean.RicetteBean;
import bean.RistoranteBean;
import connection.DriverManagerConnectionPool;

public class RistoranteModel {
	
	
	public Collection<RistoranteBean> doRetrieveAll(String order) throws SQLException {
		Connection connection =null;
		PreparedStatement preparedStatement =null;
		
		 Collection<RistoranteBean> products =new LinkedList<RistoranteBean>();
		 
		 String selectSQL="SELECT * FROM ristorante";
		 
		 if(order!= null && !order.equals("")){
			 selectSQL += " ORDER BY " + order;
		 }
		 
		 try{
			 connection = DriverManagerConnectionPool.getConnection();
			 preparedStatement= connection.prepareStatement(selectSQL);
			 
			 if(order != null && !order.equals("")){
				// preparedStatement.setString(1, order);
			 }
			 
			 ResultSet rs= preparedStatement.executeQuery();
			 
			 while(rs.next()){
				 RistoranteBean bean= new RistoranteBean();
				 
				 bean.setCitt�(rs.getString("Citt�"));
				 bean.setIndirizzo(rs.getString("Indirizzo"));
				
				 
				 
				 products.add(bean);
			 }
			 
		 } 
		 finally{
		
			 try{
				 if(preparedStatement!=null)
					 preparedStatement.close();
			 }
			 finally{
				 DriverManagerConnectionPool.releaseConnection(connection);
			 }		 
		 }
		  
		return products;
	}

	public Collection<String> doRetrieveDistinct(String order) throws SQLException {
		Connection connection =null;
		PreparedStatement preparedStatement =null;
		
		 Collection<String> products =new LinkedList<String>();
		 
		 String selectSQL="SELECT DISTINCT(Citt�) FROM ristorante";
		 
		 if(order!= null && !order.equals("")){
			 selectSQL += " ORDER BY " + order;
		 }
		 
		 try{
			 connection = DriverManagerConnectionPool.getConnection();
			 preparedStatement= connection.prepareStatement(selectSQL);
			 
			 if(order != null && !order.equals("")){
				// preparedStatement.setString(1, order);
			 }
			 
			 ResultSet rs= preparedStatement.executeQuery();
			 
			 while(rs.next()){
				
				 products.add(rs.getString("Citt�"));
			 }
			 
		 } 
		 finally{
		
			 try{
				 if(preparedStatement!=null)
					 preparedStatement.close();
			 }
			 finally{
				 DriverManagerConnectionPool.releaseConnection(connection);
			 }		 
		 }
		  
		return products;
	}
	
	
	

	public Collection<String> TrovaMenu(String Citt�,String Indirizzo) throws SQLException{
		Connection connection =null;
		PreparedStatement preparedStatement =null;
		
		 Collection<String> products =new LinkedList<String>();
		 
		 String selectSQL="SELECT Tipo FROM menu,ha WHERE menu.ID = ha.ID AND ha.Citt�=? AND ha.Indirizzo=?";
		 
		 
		 
		 try{
			 connection = DriverManagerConnectionPool.getConnection();
			 preparedStatement= connection.prepareStatement(selectSQL);
			 
			 preparedStatement.setString(1, Citt�);
			 preparedStatement.setString(2, Indirizzo);
		
			 
			 
			 ResultSet rs= preparedStatement.executeQuery();
			 
			 while(rs.next()){
				 MenuBean bean= new MenuBean();
				 
				 bean.setID(rs.getInt("ID"));
				 bean.setTipo(rs.getString("Tipo"));
				
				 
				 products.add(bean.getTipo());
				 
			 }
			 System.out.println(products.toString());
		 } 
		 finally{
		
			 try{
				 if(preparedStatement!=null)
					 preparedStatement.close();
			 }
			 finally{
				 DriverManagerConnectionPool.releaseConnection(connection);
			 }		 
		 }
		  
		return products;
		
	}
	
	
	public Collection<String> TrovaVia(String Citt�) throws SQLException{
		Connection connection =null;
		PreparedStatement preparedStatement =null;
		
		 Collection<String> products =new LinkedList<String>();
		 
		 String selectSQL="SELECT Indirizzo FROM ristorante WHERE Citt�=?";
		 
		 
		 
		 try{
			 connection = DriverManagerConnectionPool.getConnection();
			 preparedStatement= connection.prepareStatement(selectSQL);
			 
			 preparedStatement.setString(1, Citt�);
			 
		
			 
			 
			 ResultSet rs= preparedStatement.executeQuery();
			 
			 while(rs.next()){
				 RistoranteBean bean= new RistoranteBean();
				 bean.setCitt�(Citt�);
				 bean.setIndirizzo(rs.getString("Indirizzo"));
				
				 
				 products.add(bean.getIndirizzo());
				 
			 }
			System.out.println(products.toString());
		 } 
		 finally{
		
			 try{
				 if(preparedStatement!=null)
					 preparedStatement.close();
			 }
			 finally{
				 DriverManagerConnectionPool.releaseConnection(connection);
			 }		 
		 }
		  
		return products;
		
	}

	
	
	int nuovo=0;
	public int InserisciRisto(RistoranteBean bean, DipendentiBean dip, String username, String password, String menu, String telefono, String telefonoR, int i) throws SQLException{
		Connection connection =null;
		PreparedStatement preparedStatement =null;
		
		int ID=0;
		
		 String selectSQL="SELECT * FROM ristorante WHERE Citt�=? AND Indirizzo=?";
		
		 
		 
		 try{
			 
			 connection = DriverManagerConnectionPool.getConnection();
			 preparedStatement= connection.prepareStatement(selectSQL);
			
			 preparedStatement.setString(1, bean.getCitt�());
			 preparedStatement.setString(2, bean.getIndirizzo());
			 ResultSet rs;
			 rs=preparedStatement.executeQuery();
		
			 if(rs.next()){
				 if(i==0){
					 	nuovo=1;
						return 0;
					}
			 }
			 else{
				 
				 selectSQL="SELECT * FROM dipendenti WHERE CF=?";
				 connection = DriverManagerConnectionPool.getConnection();
				 preparedStatement= connection.prepareStatement(selectSQL);
			
				 preparedStatement.setString(1, dip.getCF());
			
				
				 rs=preparedStatement.executeQuery();
			
				 if(rs.next()){
					if(i==0){
						nuovo=1;
						return 0; 
					}
				 }
				 else{
					 nuovo=0;
					 selectSQL="INSERT INTO ristorante(Citt�,Indirizzo) VALUES(?,?)";
					 connection = DriverManagerConnectionPool.getConnection();
					 preparedStatement= connection.prepareStatement(selectSQL);
					 
					 preparedStatement.setString(1, bean.getCitt�());
					 preparedStatement.setString(2, bean.getIndirizzo());
					 
					 preparedStatement.executeUpdate();
					
					 connection.commit();	
					 
			
					 selectSQL="INSERT INTO dipendenti(CF,ScadenzaContratto,AnniEsperienza,Nome,Cognome,Et�,Citt�,Indirizzo,Responsabile,CFRES,username,Psw) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
					 connection = DriverManagerConnectionPool.getConnection();
					 preparedStatement= connection.prepareStatement(selectSQL);
					 
					 preparedStatement.setString(1, dip.getCF());
					 preparedStatement.setString(2, dip.getScadenzaContratto());
					 preparedStatement.setInt(3, dip.getAnniEsperienza());
					 preparedStatement.setString(4, dip.getNome());	
					 preparedStatement.setString(5, dip.getCognome());
					 preparedStatement.setInt(6, dip.getEt�());
					 preparedStatement.setString(7, bean.getCitt�());
					 preparedStatement.setString(8, bean.getIndirizzo());
					 preparedStatement.setInt(9, 1);
					 preparedStatement.setString(10, dip.getCF());
					 preparedStatement.setString(11, username );
					 preparedStatement.setString(12, password);
				
					 preparedStatement.executeUpdate();
						
					 connection.commit();
				
					 
					 selectSQL="INSERT INTO telefonoris(Numero,Citt�,Indirizzo) VALUES(?,?,?)";
					
					 connection = DriverManagerConnectionPool.getConnection();
		
					 preparedStatement= connection.prepareStatement(selectSQL);
					 preparedStatement.setString(1, telefonoR);
					 preparedStatement.setString(2, bean.getCitt�());
					 preparedStatement.setString(3, bean.getIndirizzo());
					
					
					 preparedStatement.executeUpdate();
						
					 connection.commit();
				

					 selectSQL="INSERT INTO telefonodip(Numero,CFDIP) VALUES(?,?)";
					 connection = DriverManagerConnectionPool.getConnection();
					 preparedStatement= connection.prepareStatement(selectSQL);
					 preparedStatement.setString(1, telefono);
					 preparedStatement.setString(2, dip.getCF());
					
					
				
					 preparedStatement.executeUpdate();
						
					 connection.commit();
				
			 }
			 
			
			 }
			
		if(nuovo==0){
		
			 selectSQL = "SELECT ID FROM menu WHERE Tipo=?";
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, menu);
				
				rs=preparedStatement.executeQuery();
				
				if(rs.next()) {
					ID=rs.getInt("ID");
				}
			
			 selectSQL="INSERT INTO ha(Citt�,Indirizzo,ID) VALUES(?,?,?)";
			 connection = DriverManagerConnectionPool.getConnection();
			 preparedStatement= connection.prepareStatement(selectSQL);
			 
			 preparedStatement.setString(1, bean.getCitt�());
			 preparedStatement.setString(2, bean.getIndirizzo());
			 preparedStatement.setInt(3, ID);
		
			 preparedStatement.executeUpdate();
				
			 connection.commit();
		
		
			}
		 } 
		 catch(SQLException e){
			 
		 }
		 finally{
			 try{
				 if(preparedStatement!=null)
					 preparedStatement.close();
			 }
			 finally{
				 DriverManagerConnectionPool.releaseConnection(connection);
			 }		 
		 }
		 if(nuovo==1){
			 return 0;
		 }
		 else{
			 return 1;
		 }
	}
		
	
	public Collection<DipendentiBean> TrovaDip(String citt�, String indirizzo, ClienteBean beanAdmin) throws SQLException{
		Connection connection =null;
		PreparedStatement preparedStatement =null;
		
		 String selectSQL="SELECT * FROM dipendenti WHERE Citt�=? AND Indirizzo=? AND Responsabile=0";
		 
		 Collection<DipendentiBean> dipe= new ArrayList<DipendentiBean>();
		 
		 try{
			 
			 connection = DriverManagerConnectionPool.getConnection();
			 preparedStatement= connection.prepareStatement(selectSQL);
			
			 preparedStatement.setString(1, citt�);
			
			 preparedStatement.setString(2, indirizzo);
			 ResultSet rs;
			 rs=preparedStatement.executeQuery();
			 
			 while(rs.next()){
				 DipendentiBean bean= new DipendentiBean();
				 bean.setCF(rs.getString("CF"));
				 bean.setAnniEsperienza(rs.getInt("AnniEsperienza"));
				 bean.setCFRES(beanAdmin.getCF());
				 bean.setCitt�(citt�);
				 bean.setIndirizzo(indirizzo);
				 bean.setCognome(rs.getString("Cognome"));
				 bean.setNome(rs.getString("Nome"));
				 bean.setScadenzaContratto(rs.getString("ScadenzaContratto"));
				 bean.setEt�(rs.getInt("Et�"));
				 bean.setAdmin(0);
				 
				 dipe.add(bean);
			 }
		
		 } 
		 finally{
		
			 try{
				 if(preparedStatement!=null)
					 preparedStatement.close();
			 }
			 finally{
				 DriverManagerConnectionPool.releaseConnection(connection);
			 }		 
		 }
		  
		 return dipe;
	}
	
	
	public void eliminaRisto(String citt�, String indirizzo) throws SQLException{
		Connection connection =null;
		PreparedStatement preparedStatement =null;
		
		 
		 String selectSQL="DELETE FROM ristorante WHERE Citt�=? AND Indirizzo=?";
		 
		 
		 
		 try{
			 connection = DriverManagerConnectionPool.getConnection();
			 preparedStatement= connection.prepareStatement(selectSQL);
			 
			 preparedStatement.setString(1, citt�);
			 preparedStatement.setString(2, indirizzo);
		
			 preparedStatement.executeUpdate();
				connection.commit();
			 
		 } 
		
		 finally{
		
			 try{
				 if(preparedStatement!=null)
					 preparedStatement.close();
			 }
			 finally{
				 DriverManagerConnectionPool.releaseConnection(connection);
			 }		 
		 }
		
	}

	
}
