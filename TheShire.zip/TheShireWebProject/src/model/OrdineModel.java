package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import bean.ClienteBean;
import bean.RicetteBean;
import bean.RistoranteBean;
import connection.DriverManagerConnectionPool;

public class OrdineModel {
	
	public void Acquista(ClienteBean bean, RistoranteBean risto, RicetteBean ricetta, int i) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int Cod=0;
		String query="SELECT max(Codice) FROM ordine";
		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(query);
			ResultSet rs;
			rs= preparedStatement.executeQuery();
			if(rs.next()){
					if(i==0)
						Cod=rs.getInt("max(Codice)")+1;
					else
						Cod=rs.getInt("max(Codice)");
			}
			if(i==0){
				query="INSERT INTO ordine(Codice,Data,Ora,Citt�,Indirizzo,CFCliente) VALUES(?,?,?,?,?,?)";
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, Cod);
				preparedStatement.setString(2, getDateTime());
				preparedStatement.setString(3, getOraAttuale());
				preparedStatement.setString(4, risto.getCitt�());
				preparedStatement.setString(5, risto.getIndirizzo());
				preparedStatement.setString(6, bean.getCF());
				preparedStatement.executeUpdate();
				connection.commit();
			}
			
			System.out.println(Cod);
			System.out.println(ricetta.getNome());
			
			query="INSERT INTO compone(NomeRicetta, CODICE) VALUES(?,?)";
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, ricetta.getNome() );
			preparedStatement.setInt(2, Cod);
		
			preparedStatement.executeUpdate();
			connection.commit();
			
			
			query= "DELETE FROM carrello WHERE CF=?";
			
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1, bean.getCF() );
			
			preparedStatement.executeUpdate();
			connection.commit();
			
			
			
		}
		
		 finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
	}
}
	
	
	private String getDateTime(){
		DateFormat dateFormat= new SimpleDateFormat("dd-MM-yyyy");
		Date date= new Date();
		return dateFormat.format(date);
	}
	
	public String getOraAttuale()
	{
		java.util.TimeZone t=java.util.TimeZone.getTimeZone("ECT");
		java.util.Calendar oggi = java.util.Calendar.getInstance(t);
	
		String s = "";
		String minuti = "" + oggi.get(oggi.MINUTE);
		String ora = "" +oggi.get(oggi.HOUR_OF_DAY);
	
		if (minuti.length() == 1)
		minuti = "0" + minuti;
		if (ora.length() == 1)
		ora = "0" + ora;
		s=ora + ":" + minuti;
	
		return s;
	}
}
