package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import bean.ClienteBean;
import bean.IngredientiBean;
import bean.OrdineBean;
import bean.RicetteBean;
import connection.DriverManagerConnectionPool;



public class RicetteModel {
	
	public void Acquista(RicetteBean ricetta, OrdineBean ordine) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "INSERT INTO ordine (Codice,Data,Ora,Citt�,Indirizzo,CF) VALUES (?, ?, ?, ?, ?, ?)";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setInt(1, ordine.getCodice());
			preparedStatement.setString(2, ordine.getData());
			preparedStatement.setString(3, ordine.getOra());
			preparedStatement.setString(4, ordine.getCitt�());
			preparedStatement.setString(5, ordine.getIndirizzo());
			preparedStatement.setString(6, ordine.getCFCliente());
			preparedStatement.executeUpdate();

			connection.commit();
			
			insertSQL="INSERT INTO compone(NomeRicetta,Codice) VALUES(?,?)";
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, ricetta.getNome());
			preparedStatement.setInt(3, ordine.getCodice());
			
			preparedStatement.executeUpdate();

			connection.commit();
			
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}

	}
	
	
	public void inserisciRicetta(RicetteBean ricetta,String ing, IngredientiBean beanI,String menu) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int ID=0;
		
		String insertSQL = "SELECT * FROM ricetta WHERE ricetta.Nome=?";
		
		
		try {
			
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, ricetta.getNome());
			ResultSet rs;
			rs=preparedStatement.executeQuery();
			if(rs.next()){
				
				
			}
			else{
				insertSQL = "INSERT INTO ricetta(Nome, Categoria, Prezzo) VALUES (?, ?, ?)";
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(insertSQL);
				preparedStatement.setString(1, ricetta.getNome());
				preparedStatement.setString(2, ricetta.getCategoria());
				preparedStatement.setDouble(3, ricetta.getPrezzo());
				
				preparedStatement.executeUpdate();
	
				connection.commit();
			}
			
			if(beanI.getNome()!=null){
				//aggiungere controllo se esiste ingrediente
				insertSQL = "SELECT * FROM ingredienti WHERE Nome=?";
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(insertSQL);
				preparedStatement.setString(1, beanI.getNome());
				rs=preparedStatement.executeQuery();
				
				if(rs.next()) {
					System.out.println("trovato Ing");
				
				}
				else{
					insertSQL = "INSERT INTO ingredienti(Nome, Quantit�) VALUES (?, ?)";
					connection = DriverManagerConnectionPool.getConnection();
					preparedStatement = connection.prepareStatement(insertSQL);
					preparedStatement.setString(1, beanI.getNome());
					preparedStatement.setInt(2,beanI.getQuantit�());
					preparedStatement.executeUpdate();
					
					
					connection.commit();
					
					insertSQL = "INSERT INTO usa(NomeRicetta, NomeIngrediente) VALUES (?, ?)";
					connection = DriverManagerConnectionPool.getConnection();
					preparedStatement = connection.prepareStatement(insertSQL);
					preparedStatement.setString(1, ricetta.getNome());
					preparedStatement.setString(2, beanI.getNome());
					preparedStatement.executeUpdate();
				
					connection.commit();
				}
			}
			

			insertSQL = "SELECT ID FROM menu WHERE Tipo=?";
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, menu);
			
			rs=preparedStatement.executeQuery();
			
			if(rs.next()) {
				ID=rs.getInt("ID");
			}
			System.out.println(ID);
			
			insertSQL = "SELECT * FROM formato,menu,ricetta WHERE ricetta.Nome=formato.Nome AND formato.ID=menu.ID AND formato.ID=? AND formato.Nome=?";
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setInt(1,ID);
			preparedStatement.setString(2, ricetta.getNome() );
			rs=preparedStatement.executeQuery();
			
			if(rs.next()) {
				
			
			}
			else{
			
			insertSQL = "INSERT INTO formato(ID, Nome) VALUES (?, ?)";
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setInt(1, ID);
			preparedStatement.setString(2, ricetta.getNome());
			preparedStatement.executeUpdate();
		
			connection.commit();
			}
			
			if(ing!=null){
				insertSQL = "INSERT INTO usa(NomeRicetta, NomeIngrediente) VALUES (?, ?)";
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(insertSQL);
				preparedStatement.setString(1, ricetta.getNome());
				preparedStatement.setString(2, ing);
				preparedStatement.executeUpdate();
			
				connection.commit();
			}
		
			
			
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
	
	
	public void CancellaRicetta(String nome) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "DELETE FROM ricetta WHERE Nome= ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, nome);
			preparedStatement.executeUpdate();

			connection.commit();
			
			/*insertSQL = "DELETE FROM usa WHERE Nome= ?";
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, nome);
			preparedStatement.executeUpdate();

			connection.commit();
			
			insertSQL = "DELETE FROM formato WHERE Nome= ?";
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, nome);
			preparedStatement.executeUpdate();

			connection.commit();*/
			
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
	
	
	public RicetteBean doRetrieveByKey(String nome) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		RicetteBean bean = new RicetteBean();

		String selectSQL = "SELECT * FROM ricetta WHERE Nome= ?";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, nome);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				bean.setNome(rs.getString("Nome"));
				bean.setCategoria(rs.getString("Categoria"));
				bean.setPrezzo(rs.getDouble("Prezzo"));
				
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return bean;
	}
	
	
	public Collection<RicetteBean> doRetrieveAll(String order) throws SQLException {
		Connection connection =null;
		PreparedStatement preparedStatement =null;
		
		 Collection<RicetteBean> products =new LinkedList<RicetteBean>();
		 
		 String selectSQL="SELECT * FROM ricetta";
		 
		 if(order!= null && !order.equals("")){
			 selectSQL += " ORDER BY " + order;
		 }
		 
		 try{
			 connection = DriverManagerConnectionPool.getConnection();
			 preparedStatement= connection.prepareStatement(selectSQL);
			 
			 if(order != null && !order.equals("")){
				// preparedStatement.setString(1, order);
			 }
			 
			 ResultSet rs= preparedStatement.executeQuery();
			 
			 while(rs.next()){
				 RicetteBean bean= new RicetteBean();
				 
				 bean.setNome(rs.getString("Nome"));
				 bean.setCategoria(rs.getString("Categoria"));
				 bean.setPrezzo(rs.getDouble("Prezzo"));
				 
				 
				 products.add(bean);
			 }
			 
		 } 
		 finally{
		
			 try{
				 if(preparedStatement!=null)
					 preparedStatement.close();
			 }
			 finally{
				 DriverManagerConnectionPool.releaseConnection(connection);
			 }		 
		 }
		  
		return products;
	}
	
	
	public Collection<RicetteBean> TrovaRicette(String citt�,String indirizzo, String menu, String tipopasto) throws SQLException {
		Connection connection =null;
		PreparedStatement preparedStatement =null;
		
		 Collection<RicetteBean> products =new LinkedList<RicetteBean>();
		 int ID=0;
		 	
		 String selectSQL = "SELECT ID FROM menu WHERE Tipo=?";
		 System.out.println("coaa");
		 try{
			 	connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, menu);
				ResultSet rs;
				rs=preparedStatement.executeQuery();
				
				if(rs.next()) {
					ID=rs.getInt("ID");
				}
				
				System.out.println(ID);
			 
			 selectSQL="SELECT ricetta.Nome, ricetta.Categoria, ricetta.Prezzo FROM ricetta,menu,ristorante,formato,ha WHERE ristorante.Citt�= ? AND ristorante.Indirizzo=? AND menu.ID=? AND ricetta.Categoria=? AND menu.ID=ha.ID AND ristorante.Citt�=ha.Citt� AND ristorante.Indirizzo=ha.Indirizzo AND formato.Nome=ricetta.Nome AND menu.ID=formato.ID";
			 connection = DriverManagerConnectionPool.getConnection();
			 preparedStatement = connection.prepareStatement(selectSQL);
			 preparedStatement.setString(1,citt�);	
			 preparedStatement.setString(2,indirizzo);	
			 preparedStatement.setInt(3,ID);	
			 preparedStatement.setString(4,tipopasto);	
			 
			 rs=preparedStatement.executeQuery();
			 
			 while(rs.next()){
				 RicetteBean bean= new RicetteBean();
				 
				 bean.setNome(rs.getString("Nome"));
				 bean.setCategoria(rs.getString("Categoria"));
				 bean.setPrezzo(rs.getDouble("Prezzo"));
				 
				 products.add(bean);
			 }
		 } 
		 finally{
		
			 try{
				 if(preparedStatement!=null)
					 preparedStatement.close();
			 }
			 finally{
				 DriverManagerConnectionPool.releaseConnection(connection);
			 }		 
		 }
		  
		return products;
	}
	
	
	public void aggiornaQuantity(RicetteBean bean, ClienteBean cliente) throws SQLException{
		Connection connection =null;
		PreparedStatement preparedStatement =null;
		
		
		 String selectSQL = "SELECT ID FROM carrello WHERE carrello.CF=? ";
		 

		 try{
			 
			 	connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1,cliente.getCF());	
				ResultSet rs;
				rs=preparedStatement.executeQuery();
				 
				 if(rs.next()){
					 	int ID= rs.getInt("ID");
					 	selectSQL = "SELECT Quantit� FROM contiene WHERE contiene.NomeRicetta=? AND ID=?";
					 	connection = DriverManagerConnectionPool.getConnection();
						preparedStatement = connection.prepareStatement(selectSQL);
						preparedStatement.setString(1,bean.getNome());	
						preparedStatement.setInt(2,ID);	
						rs=preparedStatement.executeQuery();
						 
						 if(rs.next()){
							bean.setQuantit�Carr(rs.getInt("Quantit�"));
						 }
				 }
			
		 } 
		 finally{
		
			 try{
				 if(preparedStatement!=null)
					 preparedStatement.close();
			 }
			 finally{
				 DriverManagerConnectionPool.releaseConnection(connection);
			 }		 
		 }
		  
	
		
	}
	
	
	public void aggiornaPrice(double prezzo, String nome) throws SQLException{
		Connection connection =null;
		PreparedStatement preparedStatement =null;
		 	
		 String selectSQL = "UPDATE ricetta SET prezzo=? WHERE ricetta.Nome=?";

		 try{
			 	connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setDouble(1,prezzo);	
				preparedStatement.setString(2,nome);
				
				preparedStatement.executeUpdate();
				 
				connection.commit();
		 } 
		 finally{
		
			 try{
				 if(preparedStatement!=null)
					 preparedStatement.close();
			 }
			 finally{
				 DriverManagerConnectionPool.releaseConnection(connection);
			 }		 
		 }
	
	}
	
	public void aggiornaQ(int quantity, String nome) throws SQLException{
		Connection connection =null;
		PreparedStatement preparedStatement =null;
		 	
		 String selectSQL = "UPDATE ingredienti SET Quantit�=? WHERE Nome=?";

		 try{
			 	connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setDouble(1,quantity);	
				preparedStatement.setString(2,nome);
				
				preparedStatement.executeUpdate();
				 
				connection.commit();
		 } 
		 finally{
		
			 try{
				 if(preparedStatement!=null)
					 preparedStatement.close();
			 }
			 finally{
				 DriverManagerConnectionPool.releaseConnection(connection);
			 }		 
		 }
	
	}
}


