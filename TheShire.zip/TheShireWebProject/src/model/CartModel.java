package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.ClienteBean;
import bean.RicetteBean;
import connection.DriverManagerConnectionPool;


public class CartModel {
	int ID;
	List<RicetteBean> products;
	Double PrezzoTot;
	
	public CartModel(){
		ID=0;
		products= new ArrayList<RicetteBean>();
		PrezzoTot=0.0;
	}
	
	public void addProduct(RicetteBean product,String CF) throws SQLException{
		Connection connection = null;
		ID=0;
		
		PreparedStatement preparedStatement = null;
		String insertSQL = "SELECT * FROM carrello WHERE CF=?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			
			preparedStatement.setString(1, CF);
			ResultSet rs;
			rs=preparedStatement.executeQuery();
			if(rs.next()){
			
				ID=rs.getInt("ID");
				
			}
			else{
				insertSQL = "SELECT * FROM carrello";
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(insertSQL);
				
				rs=preparedStatement.executeQuery();
				if(rs.next()){
					insertSQL = "SELECT max(ID) FROM carrello";
					connection = DriverManagerConnectionPool.getConnection();
					preparedStatement = connection.prepareStatement(insertSQL);
					ResultSet rp;
					rp=preparedStatement.executeQuery();
					if(rp.next()){
						ID=rp.getInt("max(ID)");
						ID++;
					
					}
					
					insertSQL = "INSERT INTO carrello(ID,CF) VALUES(?,?)";
					connection = DriverManagerConnectionPool.getConnection();
					preparedStatement = connection.prepareStatement(insertSQL);
					preparedStatement.setInt(1, ID);
					preparedStatement.setString(2, CF);
					
					preparedStatement.executeUpdate();
					connection.commit();
					
					
				}
				else{
					ID=1;
					insertSQL = "INSERT INTO carrello(ID,CF) VALUES(?,?)";
					connection = DriverManagerConnectionPool.getConnection();
					preparedStatement = connection.prepareStatement(insertSQL);
					preparedStatement.setInt(1, ID);
					preparedStatement.setString(2, CF);
					
					preparedStatement.executeUpdate();
					connection.commit();
				}
					
				
			}
			
			
			insertSQL = "SELECT * FROM carrello,ricetta,contiene WHERE carrello.ID=? AND carrello.ID=contiene.ID AND contiene.NomeRicetta=Ricetta.Nome AND contiene.NomeRicetta=?";
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setInt(1, ID);
			preparedStatement.setString(2, product.getNome());

			rs=preparedStatement.executeQuery();

			if(rs.next()){
				insertSQL="UPDATE contiene SET contiene.Quantit�=? WHERE contiene.NomeRicetta=? AND ID=?";
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(insertSQL);
				
				int quantity=rs.getInt("Quantit�")+1;
				preparedStatement.setInt(1,quantity);
				preparedStatement.setString(2,product.getNome());
				preparedStatement.setInt(3, ID);
				preparedStatement.executeUpdate();
				connection.commit();
			}
		
			else{
			insertSQL = "INSERT INTO contiene(ID,NomeRicetta,Quantit�) VALUES (?,?,?)";
	
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setInt(1, ID);
			preparedStatement.setString(2, product.getNome());
			preparedStatement.setInt(3,1);
			
			preparedStatement.executeUpdate();

			connection.commit();
			products.add(product);
		
		}
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}

		
	}
	
	
	
	public void deleteProduct(RicetteBean product) throws SQLException{
			
				Connection connection = null;
				PreparedStatement preparedStatement = null;
				String insertSQL = "SELECT * FROM contiene,carrello,ricetta WHERE carrello.ID=contiene.ID AND contiene.NomeRicetta=Ricetta.Nome AND contiene.NomeRicetta=?";
				
				try {
					
					connection = DriverManagerConnectionPool.getConnection();
					preparedStatement = connection.prepareStatement(insertSQL);
					
					preparedStatement.setString(1, product.getNome());
					ResultSet rs;
					rs=preparedStatement.executeQuery();
		
					if(rs.next()){
						
						if(rs.getInt("Quantit�")==1){
							remove(product);
							insertSQL = "DELETE FROM contiene WHERE contiene.NomeRicetta= ?";
							connection = DriverManagerConnectionPool.getConnection();
							preparedStatement = connection.prepareStatement(insertSQL);
							preparedStatement.setString(1, product.getNome());
							preparedStatement.executeUpdate();
	
							connection.commit();
							
					
					}
					else if(rs.getInt("Quantit�")>1){
							product.setQuantit�Carr(product.getQuantit�Carr()-1);
						
							insertSQL="UPDATE contiene SET contiene.Quantit�=? WHERE contiene.NomeRicetta=?";
							connection = DriverManagerConnectionPool.getConnection();
							preparedStatement = connection.prepareStatement(insertSQL);	
							int quantity=rs.getInt("Quantit�")-1;
							preparedStatement.setInt(1,quantity);
							preparedStatement.setString(2,product.getNome());
							preparedStatement.executeUpdate();
							connection.commit();
							
						
						}
					}
					
					
				}
						finally {
							try {
								if (preparedStatement != null)
									preparedStatement.close();
							} finally {
								DriverManagerConnectionPool.releaseConnection(connection);
							}
						}

	}
	
	
	
	public void remove(RicetteBean product){
		for (RicetteBean prod: products) {
			if(prod.getNome().equals(product.getNome())){
						product.setQuantit�Carr(0);
						products.remove(prod);
						break;
			}
		}
	}
	
	
	public double calcoloTot(){
		PrezzoTot=0.0;
		for (RicetteBean prod : products) {
			PrezzoTot=PrezzoTot+(prod.getPrezzo()*prod.getQuantit�Carr());
		}
		return PrezzoTot;
	}
	
	
	public Double getPrezzoTot() {
		return PrezzoTot;
	}

	public void setPrezzoTot(Double prezzoTot) {
		PrezzoTot = prezzoTot;
	}

	public List<RicetteBean> getProducts(){
		return products;
	}

	public void setProducts(List<RicetteBean> products) {
		this.products = products;
	}
	

	
}
