package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import bean.ClienteBean;
import bean.DipendentiBean;
import bean.RistoranteBean;
import connection.DriverManagerConnectionPool;

public class DipendentiModel {
	
	
	
	public Collection<RistoranteBean> cercaRisto(String CF) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		Collection<RistoranteBean> risto= new ArrayList<RistoranteBean>();
		
		String insertSQL = "SELECT ristorante.Citt�, ristorante.Indirizzo FROM ristorante,dipendenti WHERE CF=? AND dipendenti.Citt�=ristorante.Citt� AND dipendenti.Indirizzo=ristorante.Indirizzo";
		
		
		try {
			
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1,CF);
			ResultSet rs;
			rs=preparedStatement.executeQuery();
			
			while(rs.next()){
				RistoranteBean bean= new RistoranteBean();
				bean.setCitt�(rs.getString("Citt�"));
				bean.setIndirizzo(rs.getString("Indirizzo"));
				
				risto.add(bean);
			}
		
			connection.commit();
		     
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return risto;
	}

}
