package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.ClienteBean;
import bean.RicetteBean;
import connection.DriverManagerConnectionPool;

public class ClientModel {
	
	public ClienteBean checkUser(String username, String password) throws SQLException{
		int flag=0;
		int trovato=0;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ClienteBean utente=new ClienteBean();
		String query="SELECT * FROM cliente WHERE usernameC=? AND Psw=?";
	
		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				flag=1;
				trovato=1;
				//System.out.println("trovatocli");
				utente=doRetrieveByUsername(username,flag);

			}
			preparedStatement.close();
			
		if(flag==0){
				PreparedStatement prepareStatement = null;
				String secoquery="SELECT * FROM dipendenti WHERE Username= ? AND Psw=?";
				connection = DriverManagerConnectionPool.getConnection();
				prepareStatement = connection.prepareStatement(secoquery);
				prepareStatement.setString(1, username);
				prepareStatement.setString(2, password);
				ResultSet re = prepareStatement.executeQuery();
			
				if(re.next()) {
					flag=0;
					trovato=1;
					//System.out.println("trovatodip");
					utente=doRetrieveByUsername(username,flag);
				}
				
			}

			/*System.out.println(trovato);
			if(trovato==1){
				System.out.println("Ok");
			}
			else if(trovato==0) throw new Exception("Invalid login and password");*/
		}
		catch(Exception e){
			System.out.println("Errore connessione");
		}
		 finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
		return utente;
	}
	
	
//------------------------------------------------------------------------------------------------------------
	
	public ClienteBean doRetrieveByUsername(String username,int flag ) throws SQLException{
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String selectSQL = "SELECT * FROM cliente WHERE usernameC=?";
		ClienteBean utente= new ClienteBean();
		
		try {
			if(flag==1){
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setString(1, username);
		//	System.out.println("sono in cliente flag1");
			ResultSet rs = preparedStatement.executeQuery();
			rs.next();
			utente.setCF(rs.getString("CF"));
			utente.setSurname(rs.getString("Cognome"));
			utente.setName(rs.getString("Nome"));
			utente.setMail(rs.getString("Mail"));
			utente.setUsername(rs.getString("usernameC"));
			utente.setPassword(rs.getString("Psw"));
			utente.setAdmin(rs.getInt("Admin")); //0
			//System.out.println(utente.toString());

			}
			
			else if(flag==0){
				
			//System.out.println("sono in dipendente flag0");
			selectSQL = "SELECT * FROM dipendenti WHERE username= ?";	
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement =	connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, username);

			ResultSet rs = preparedStatement.executeQuery();
		
			rs.next();
			utente.setCF(rs.getString("CF"));
			utente.setSurname(rs.getString("Cognome"));
			utente.setName(rs.getString("Nome"));
			utente.setUsername(rs.getString("username"));
			utente.setPassword(rs.getString("Psw"));
			utente.setAdmin(rs.getInt("Responsabile"));//1
			
			System.out.println(utente.toString());
			}
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return utente;
	}
	
	
//------------------------------------------------------------------------------------------------------------
	public void doSave(ClienteBean cliente) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "INSERT INTO cliente (CF,Cognome,Nome,Mail,usernameC,Psw,admin) VALUES (?, ?, ?, ?, ?, ? , ?)";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, cliente.getCF());
			preparedStatement.setString(2, cliente.getSurname());
			preparedStatement.setString(3, cliente.getName());
			preparedStatement.setString(4, cliente.getMail());
			preparedStatement.setString(5, cliente.getUsername());
			preparedStatement.setString(6, cliente.getPassword());
			preparedStatement.setInt(7, cliente.getAdmin());
			preparedStatement.executeUpdate();

			connection.commit();
			
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}

	}
	
//----------------------------------------------------------------------------------------------------------
	
	public boolean alreadyExists(ClienteBean bean) throws SQLException{
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String query="SELECT * FROM cliente WHERE UsernameC= ? OR Mail= ?";
	
		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, bean.getUsername());
			preparedStatement.setString(2, bean.getMail());
			
			ResultSet rs = preparedStatement.executeQuery();
		
			if(!rs.next()){
				return true;
			}
			
			}
			catch(Exception e){
				System.out.println("Errore connessione");
			}
			 finally {
				try {
					if (preparedStatement != null)
						preparedStatement.close();
				} finally {
					DriverManagerConnectionPool.releaseConnection(connection);
				}
			}
		return false;
	}
	
	
//------------------------------------------------------------------------------------------------------------------	

	public ArrayList<RicetteBean> caricaCarrello(ClienteBean bean) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		int ID=0;
		ArrayList<RicetteBean> ricette= new ArrayList<RicetteBean>();
		String insertSQL = "SELECT ID FROM carrello WHERE CF=?";

		try {
			
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, bean.getCF());
			ResultSet rs;
			rs=preparedStatement.executeQuery();
			if(rs.next()){
				ID=rs.getInt("ID");
			}
				insertSQL = "SELECT * FROM contiene,ricetta,carrello WHERE contiene.ID=? AND contiene.NomeRicetta=ricetta.Nome AND contiene.ID=carrello.ID";
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(insertSQL);
				preparedStatement.setInt(1, ID);
				rs=preparedStatement.executeQuery();
				while(rs.next()){
					RicetteBean piatto= new RicetteBean();
					piatto.setNome(rs.getString("Nome"));
					piatto.setCategoria(rs.getString("Categoria"));
					piatto.setPrezzo(rs.getDouble("Prezzo"));
					
					ricette.add(piatto);
				
				
			}
			
			System.out.println(ricette.toString());
			
			
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return ricette;
		
	}
	
	
	
	public void changePsw(String username, String password, ClienteBean bean) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
	
		String insertSQL = "UPDATE dipendenti SET Username=? WHERE CF=? AND Responsabile=1";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, bean.getCF());
			preparedStatement.executeUpdate();
			
			connection.commit();
			
			insertSQL = "UPDATE dipendenti SET Psw=? WHERE CF=? AND Responsabile=1";
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, password);
			preparedStatement.setString(2, bean.getCF());
			preparedStatement.executeUpdate();
			
			connection.commit();
			
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
	}
/*--------------------------------------------------------------------------------------------------------*/	
	public static void table(ResultSet rs){
		ResultSetMetaData md;
		int n=0;
		try{
			md = rs.getMetaData();
			for(int i=1; i<=md.getColumnCount(); i++){
				if(n<md.getColumnLabel(i).length())
					n = md.getColumnLabel(i).length();
			}
			while(rs.next()){
				for(int i=1; i<=md.getColumnCount(); i++){
					if(n<rs.getString(i).length())
						n = rs.getString(i).length();
				}
			}
			rs.beforeFirst();
			for(int i=0; i<md.getColumnCount()*n+md.getColumnCount(); i++)
				System.out.print("-");
			System.out.println();
			
			System.out.print("|");
			for(int i=1; i<=md.getColumnCount(); i++){
				System.out.print(md.getColumnLabel(i));
				for(int j=0; j<n-md.getColumnLabel(i).length(); j++)
					System.out.print(" ");
				System.out.print("|");
			}
			System.out.println();
			
			for(int i=0; i<md.getColumnCount()*n+md.getColumnCount(); i++)
				System.out.print("-");
			System.out.println();
			
			while(rs.next()){
				System.out.print("|");
				for(int i=1; i<=md.getColumnCount(); i++){
					System.out.print(rs.getString(i));
					for(int j=0; j<n-rs.getString(i).length(); j++)
						System.out.print(" ");
					System.out.print("|");
				}
				System.out.println();
				
				for(int i=0; i<md.getColumnCount()*n+md.getColumnCount(); i++)
					System.out.print("-");
				System.out.println();
			}
			rs.close();
		}catch(SQLException e){
			System.out.println(e);
		}
	}
}