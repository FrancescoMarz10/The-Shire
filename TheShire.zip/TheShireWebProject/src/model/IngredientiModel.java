package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import bean.IngredientiBean;
import bean.RistoranteBean;
import connection.DriverManagerConnectionPool;

public class IngredientiModel {

	
	public Collection<IngredientiBean> doRetrieveAll() throws SQLException {
		Connection connection =null;
		PreparedStatement preparedStatement =null;
		
		 Collection<IngredientiBean> ing =new LinkedList<IngredientiBean>();
		 
		 String selectSQL="SELECT * FROM ingredienti";
		
		 try{
			 connection = DriverManagerConnectionPool.getConnection();
			 preparedStatement= connection.prepareStatement(selectSQL);
		
			 ResultSet rs= preparedStatement.executeQuery();
			 
			 while(rs.next()){
				 IngredientiBean bean= new IngredientiBean();
				 
				 bean.setNome(rs.getString("Nome"));
				 bean.setQuantit�(rs.getInt("Quantit�"));
				
				 
				 
				 ing.add(bean);
			 }
			 
		 } 
		 finally{
		
			 try{
				 if(preparedStatement!=null)
					 preparedStatement.close();
			 }
			 finally{
				 DriverManagerConnectionPool.releaseConnection(connection);
			 }		 
		 }
		  
		return ing;
	}
}
