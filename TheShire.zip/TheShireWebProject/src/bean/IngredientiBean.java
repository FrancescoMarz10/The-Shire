package bean;

public class IngredientiBean {
		private String Nome;
		private int quantit�;
		
		public IngredientiBean(){
			Nome="";
			quantit�=0;
		}
		
		public IngredientiBean(String aName, int aQuantity){
			Nome=aName;
			quantit�=aQuantity;
		}

		@Override
		public String toString() {
			return "IngredientiBean [Nome=" + Nome + ", quantit�=" + quantit� + "]";
		}

		public String getNome() {
			return Nome;
		}

		public void setNome(String nome) {
			Nome = nome;
		}

		public int getQuantit�() {
			return quantit�;
		}

		public void setQuantit�(int quantit�) {
			this.quantit� = quantit�;
		}
}
