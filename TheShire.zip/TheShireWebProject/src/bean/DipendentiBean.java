package bean;

public class DipendentiBean {
	private String CF;
	private String ScadenzaContratto;
	private int AnniEsperienza;
	private String Nome;
	private String Cognome;
	private int Et�;
	private String Citt�;
	private String Indirizzo;
	private String CFRES;
	private static int admin=0;
	
	public DipendentiBean(){
		CF="";
		ScadenzaContratto="";
		AnniEsperienza=0;
		Nome="";
		Cognome="";
		Et�=0;
		Citt�="";
		Indirizzo="";
		CFRES="";
		admin=0;
	}
	
	public DipendentiBean(String aCF, String aScad, int Ann, String Nom, String Cog, int et, String aCity, String anAddress, String CFR, int AnAdmin){
		CF=aCF;
		ScadenzaContratto=aScad;
		AnniEsperienza=Ann;
		Nome=Nom;
		Cognome=Cog;
		Et�=et;
		Citt�=aCity;
		Indirizzo=anAddress;
		CFRES=CFR;
		admin=AnAdmin;
	}

	@Override
	public String toString() {
		return "DipendentiBean [CF=" + CF + ", ScadenzaContratto=" + ScadenzaContratto + ", AnniEsperienza="
				+ AnniEsperienza + ", Nome=" + Nome + ", Cognome=" + Cognome + ", Et�=" + Et� + ", Citt�=" + Citt�
				+ ", Indirizzo=" + Indirizzo + ", CFRES=" + CFRES + "]";
	}

	public String getCF() {
		return CF;
	}

	public void setCF(String cF) {
		CF = cF;
	}

	public String getScadenzaContratto() {
		return ScadenzaContratto;
	}

	public void setScadenzaContratto(String scadenzaContratto) {
		ScadenzaContratto = scadenzaContratto;
	}

	public int getAnniEsperienza() {
		return AnniEsperienza;
	}

	public void setAnniEsperienza(int anniEsperienza) {
		AnniEsperienza = anniEsperienza;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getCognome() {
		return Cognome;
	}

	public void setCognome(String cognome) {
		Cognome = cognome;
	}

	public int getEt�() {
		return Et�;
	}

	public void setEt�(int et�) {
		Et� = et�;
	}

	public String getCitt�() {
		return Citt�;
	}

	public void setCitt�(String citt�) {
		Citt� = citt�;
	}

	public String getIndirizzo() {
		return Indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		Indirizzo = indirizzo;
	}

	public String getCFRES() {
		return CFRES;
	}

	public void setCFRES(String cFRES) {
		CFRES = cFRES;
	}

	public static int getAdmin() {
		return admin;
	}

	public static void setAdmin(int admin) {
		DipendentiBean.admin = admin;
	}
	
	
	
}
