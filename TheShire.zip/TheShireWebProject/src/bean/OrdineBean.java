package bean;

public class OrdineBean {
	private int Codice;
	private String Data;
	private String Ora;
	private String Citt�;
	private String Indirizzo;
	private String CFCliente;
	
	
	public OrdineBean(){
		Codice=10;
		Data="";
		Ora="";
		Citt�="";
		Indirizzo="";
		CFCliente="";
	}
	
	public OrdineBean(int aCode, String aDate, String anHour, String aCity, String anAddress, String aCF){
		Codice=aCode;
		Data=aDate;
		Ora=anHour;
		Citt�=aCity;
		Indirizzo=anAddress;
		CFCliente=aCF;
	}

	@Override
	public String toString() {
		return "OrdineBean [Codice=" + Codice + ", Data=" + Data + ", Ora=" + Ora + ", Citt�=" + Citt� + ", Indirizzo="
				+ Indirizzo + ", CFCliente=" + CFCliente + "]";
	}

	public int getCodice() {
		return Codice;
	}

	public void setCodice(int codice) {
		Codice = codice;
	}

	public String getData() {
		return Data;
	}

	public void setData(String data) {
		Data = data;
	}

	public String getOra() {
		return Ora;
	}

	public void setOra(String ora) {
		Ora = ora;
	}

	public String getCitt�() {
		return Citt�;
	}

	public void setCitt�(String citt�) {
		Citt� = citt�;
	}

	public String getIndirizzo() {
		return Indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		Indirizzo = indirizzo;
	}

	public String getCFCliente() {
		return CFCliente;
	}

	public void setCFCliente(String cFCliente) {
		CFCliente = cFCliente;
	}
}
