package bean;

public class RistoranteBean {
	private String Citt�;
	private String Indirizzo;

	public RistoranteBean(){
		Citt�="";
		Indirizzo="";
	}
	
	public RistoranteBean(String aCity,String anAddress){
		Citt�=aCity;
		Indirizzo=anAddress;
	}


	@Override
	public String toString() {
		return "RistoranteBean [Citt�=" + Citt� + ", Indirizzo=" + Indirizzo + "]";
	}

	public String getCitt�() {
		return Citt�;
	}

	public void setCitt�(String citt�) {
		Citt� = citt�;
	}

	public String getIndirizzo() {
		return Indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		Indirizzo = indirizzo;
	}
}
