package bean;

public class MenuBean {
	private int ID;
	private String Tipo;
	
	public MenuBean(){
		ID=0;
		Tipo="";
	}
	
	public MenuBean(int anID, String aType){
		ID=anID;
		Tipo=aType;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getTipo() {
		return Tipo;
	}

	public void setTipo(String tipo) {
		Tipo = tipo;
	}

	@Override
	public String toString() {
		return "MenuBean [ID=" + ID + ", Tipo=" + Tipo + "]";
	}
	
	
	
}
