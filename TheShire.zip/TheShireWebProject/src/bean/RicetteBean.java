package bean;

public class RicetteBean {

		private String Nome;
		private String Categoria;
		private double Prezzo;
		private int quantit�Carr;
		
		public RicetteBean(){
			Nome="";
			Categoria="";
			Prezzo=0.0;
			quantit�Carr=0;
		}
		
		public RicetteBean(String aName, String aCategory, double aPrice,int aQuantity){
			Nome=aName;
			Categoria=aCategory;
			Prezzo=aPrice;
			quantit�Carr=aQuantity;
		}

		public String getNome() {
			return Nome;
		}

		public void setNome(String nome) {
			Nome = nome;
		}

		public String getCategoria() {
			return Categoria;
		}

		public void setCategoria(String categoria) {
			Categoria = categoria;
		}

		public double getPrezzo() {
			return Prezzo;
		}

		public void setPrezzo(double prezzo) {
			Prezzo = prezzo;
		}

		public int getQuantit�Carr() {
			return quantit�Carr;
		}

		public void setQuantit�Carr(int quantit�Carr) {
			this.quantit�Carr = quantit�Carr;
		}

		@Override
		public String toString() {
			return "RicetteBean [Nome=" + Nome + ", Categoria=" + Categoria + ", Prezzo=" + Prezzo + ", quantit�Carr="
					+ quantit�Carr + "]";
		}


}